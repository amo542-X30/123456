# AM0SP Customer App

A private customer portal for managing files and account security with Supabase Auth, Storage, and Edge Functions.

## Run & Operate

- The managed `artifacts/am0sp-customer: web` workflow runs the customer app.
- `pnpm --filter @workspace/am0sp-customer run typecheck` — check the customer app
- `pnpm --filter @workspace/am0sp-customer run build` — build the customer app
- `pnpm run typecheck` — full typecheck across all packages
- Required client configuration: `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`
- Development password-reset origin: `VITE_APP_URL` (must exactly match the app origin)

## Stack

- React, Vite, TypeScript, and Tailwind CSS
- Supabase Auth, private Storage, PostgreSQL RLS, and Edge Functions
- pnpm workspace monorepo

## Where things live

- `artifacts/am0sp-customer/src/` — customer web app
- `artifacts/am0sp-customer/supabase/` — Supabase Edge Functions, migrations, and storage verification SQL
- `artifacts/am0sp-customer/SUPABASE_SETUP.md` — external Supabase setup and verification checklist

## Architecture decisions

- The browser uses only Supabase's public client key; never put a service-role key in frontend code or `VITE_` variables.
- Password-reset redirects are restricted to explicit trusted app origins.
- Edge Function CORS uses the server-side `APP_ORIGIN` secret; never replace it with a wildcard.

## Product

The customer app supports account access, private file storage and playback, device and security settings, and passkey authentication.

## User preferences

- Preserve the imported app and continue its existing setup rather than replacing it with a new UI.

## Gotchas

- Preview hostnames can change. Update `VITE_APP_URL`, Supabase's `APP_ORIGIN`, and Supabase Auth's allowed reset URL to the exact active origin.
- Supabase-side settings require access to the Supabase project; they cannot be changed from this workspace.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
