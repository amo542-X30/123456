# AM0SP Customer Web App — Supabase setup

## Current status

The workspace has Supabase public client configuration. Read-only checks on October 5, 2026 confirmed that Supabase Auth, the files and user-settings tables, and both Edge Function preflight endpoints respond. The uploaded SQL results in `attached_assets/Supabase_Snippet_Untitled_query_1791201253822.csv` report a PRIVATE `am0sp-vault` bucket, ENABLED object RLS, and all four owner-scoped policies. Those results are supplied evidence, not a fresh authenticated storage test.

### Current blocker after import

Both deployed Edge Functions still return the previous workspace origin in `Access-Control-Allow-Origin`. This does not match the current preview and can block browser media and passkey requests. The local `VITE_APP_URL` has been updated for the current preview; the external Supabase settings still need updating:

1. Set the Supabase Edge Function secret `APP_ORIGIN` to `https://c4351641-8e18-467a-adcc-2b68a58a365e-00-xw5t2xmwqfli.pike.replit.dev`.
2. In Supabase Authentication URL Configuration, set the customer app's Site URL to that origin and allow the exact redirect `https://c4351641-8e18-467a-adcc-2b68a58a365e-00-xw5t2xmwqfli.pike.replit.dev/reset-password`.
3. Check both functions' preflight responses again; their allowed origin must match. If changing the secret does not refresh the deployed functions, redeploy them using the instructions below.
4. Verify sign-in, password recovery, upload/download, media playback, and passkeys with an authorized test account. No signed-in UI or customer-file operations have been verified in this workspace.

Use the actual current origin if the workspace changes again. Configure the separately published origin when publishing; do not use a wildcard to bypass this restriction.

The archive's `.env` was deliberately excluded. Do not restore it or use its old project credentials.

## Database and storage

Apply the migrations in `supabase/migrations/` in filename order to the new project's SQL Editor, or link the project with the Supabase CLI and run `supabase db push`:

1. `20260930095216_001_am0sp_initial_schema.sql`
2. `20260930100742_002_auto_user_settings.sql`
3. `20261002053408_20261002090000_passkey_authentication_support.sql`
4. `20261003024548_20261003000000_fix_security_audit_critical_and_high.sql`
5. `20261003024713_20261003010000_revoke_public_execute_handle_new_user.sql`
6. `20261005000000_006_ensure_private_vault_bucket.sql`

The schema uses Supabase Auth's built-in `auth.users` for customer accounts and creates these application tables:

- `folders` — per-user folder hierarchy.
- `files` — per-user metadata; file bytes are stored in Storage.
- `devices` — customer sign-in device records.
- `security_events` — customer security-event history.
- `passkeys` — WebAuthn public credential data.
- `passkey_challenges` — short-lived authentication challenges, accessible only to the server-side passkey function.
- `user_settings` — per-user appearance preferences.

The migrations enable row-level security and scope customer access to `auth.uid()`. The `am0sp-vault` Storage bucket is private; object policies restrict each authenticated user to objects under their own user-ID path.

The sixth migration safely ensures the bucket exists and is private without modifying its objects. Apply it to the configured Supabase project from the SQL Editor, or through the authenticated Supabase CLI, before testing uploads and downloads.

To verify the bucket and its owner-scoped object policies without reading customer files, run `supabase/verify_storage_access.sql` in the SQL Editor for the same project configured in this workspace. Expect a `PRIVATE` bucket status, `ENABLED` object RLS, and four `PRESENT` policies scoped to the authenticated user's folder.

There is no public backup bucket. The archive's unused backup migrations were omitted because they created a public bucket and were not used by the customer web app. The archived playback-position migrations created and then removed their table, and no current web feature uses it.

## Connect the customer app

Configure these values in the Replit workspace environment, then restart the workflow:

- `VITE_SUPABASE_URL` — URL shown in the new Supabase project's API settings.
- `VITE_SUPABASE_ANON_KEY` — the project's publishable/anon key. This is public client configuration and is protected by RLS.
- `VITE_APP_URL` — the exact trusted customer-app origin used for password-reset redirects (use `http://localhost:5173` for local Vite development).

Never use a `service_role` or other privileged key for `VITE_SUPABASE_ANON_KEY`. The app shows a setup screen rather than loading mock data if the public project configuration is missing.

In Supabase Auth settings, set the app's site URL and allow the exact password-reset redirect URL, `<VITE_APP_URL>/reset-password`. Add only the real development/production origins that the customer web app uses.

## Deploy Edge Functions

The customer app uses:

- `media-proxy` for authenticated, ownership-checked media access.
- `passkey-auth` for WebAuthn registration and authentication.

Deploy both from `supabase/functions/` after linking the Supabase CLI to the new project. Follow `supabase/config.toml` for JWT verification: `media-proxy` requires a user JWT; `passkey-auth` disables gateway JWT verification so it can start a login ceremony, and performs its own action-specific checks.

Configure `APP_ORIGIN` as an Edge Function secret using the exact trusted app origin. The functions read `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` only on the server. Keep the service-role key in the Supabase Edge Function environment; never copy it into Replit's `VITE_` variables or frontend code. Do not deploy either function until `APP_ORIGIN` and the new project's function environment are set.

## Future Replit Admin Panel

The later Admin Panel can connect to this same project using its project URL and publishable/anon key, then share these migrations and table definitions. It is not included here. Do not expose the service-role key in an Admin Panel browser bundle; any privileged admin operations will need a separately designed server-side authorization and policy model.
