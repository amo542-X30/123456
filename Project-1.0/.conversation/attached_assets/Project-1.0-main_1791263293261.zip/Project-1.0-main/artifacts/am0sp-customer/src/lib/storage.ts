import * as tus from 'tus-js-client';
import { supabase, STORAGE_BUCKET } from './supabase';
import type { FileCategory } from './types';

export interface UploadResult {
  storageKey: string;
  bucketId: string;
  sizeBytes: number;
  mimeType: string;
}

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL?.replace(/\/+$/, '') ?? '';
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY?.trim() ?? '';
const TUS_ENDPOINT = SUPABASE_URL
  ? `${SUPABASE_URL}/storage/v1/upload/resumable`
  : '';
const CHUNK_SIZE = 6 * 1024 * 1024;

export class StorageProvider {
  private bucket = STORAGE_BUCKET;

  async uploadFile(
    userId: string,
    fileId: string,
    file: File,
    onProgress?: (progress: number) => void
  ): Promise<UploadResult> {
    const storageKey = `${userId}/${fileId}`;
    const mimeType = file.type || 'application/octet-stream';

    const { data: { session } } = await supabase.auth.getSession();
    const token = session?.access_token;
    if (!token) throw new Error('An active session is required to upload files.');
    if (!SUPABASE_ANON_KEY) throw new Error('Supabase publishable key is not configured.');

    return new Promise<UploadResult>((resolve, reject) => {
      const upload = new tus.Upload(file, {
        endpoint: TUS_ENDPOINT,
        retryDelays: [0, 3000, 5000, 10000, 20000],
        chunkSize: CHUNK_SIZE,
        uploadDataDuringCreation: true,
        removeFingerprintOnSuccess: true,
        headers: {
          authorization: `Bearer ${token}`,
          apikey: SUPABASE_ANON_KEY,
          'x-upsert': 'false',
        },
        metadata: {
          bucketName: this.bucket,
          objectName: storageKey,
          contentType: mimeType,
          cacheControl: '3600',
        },
        onError: (error) => {
          reject(error);
        },
        onProgress: (bytesUploaded, bytesTotal) => {
          if (onProgress) {
            const pct = Math.round((bytesUploaded / bytesTotal) * 100);
            onProgress(pct);
          }
        },
        onSuccess: () => {
          resolve({
            storageKey,
            bucketId: this.bucket,
            sizeBytes: file.size,
            mimeType,
          });
        },
      });

      upload.findPreviousUploads().then((previousUploads) => {
        if (previousUploads.length) {
          upload.resumeFromPreviousUpload(previousUploads[0]);
        }
        upload.start();
      }).catch(() => {
        upload.start();
      });
    });
  }

  async verifyFileOwnership(storageKey: string): Promise<boolean> {
    const { data: { session } } = await supabase.auth.getSession();
    const user = session?.user;
    if (!user) return false;
    const prefix = `${user.id}/`;
    return storageKey.startsWith(prefix);
  }

  async getSignedUrl(storageKey: string, expiresIn: number = 3600): Promise<string> {
    const owns = await this.verifyFileOwnership(storageKey);
    if (!owns) throw new Error('Access denied: file does not belong to current user');

    const { data, error } = await supabase.storage
      .from(this.bucket)
      .createSignedUrl(storageKey, expiresIn);

    if (error) {
      throw new Error(`Failed to generate signed URL: ${error.message}`);
    }

    if (!data || !data.signedUrl) {
      throw new Error('Signed URL was not returned by storage provider');
    }

    return data.signedUrl;
  }

  async getBlobUrl(storageKey: string): Promise<string> {
    const owns = await this.verifyFileOwnership(storageKey);
    if (!owns) throw new Error('Access denied: file does not belong to current user');

    const { data, error } = await supabase.storage
      .from(this.bucket)
      .download(storageKey);

    if (error) throw new Error(`Failed to download file: ${error.message}`);
    if (!data) throw new Error('No data returned from storage');

    return URL.createObjectURL(data);
  }

  async deleteFile(storageKey: string): Promise<void> {
    const { error } = await supabase.storage
      .from(this.bucket)
      .remove([storageKey]);

    if (error) {
      throw new Error(`Failed to delete file from storage: ${error.message}`);
    }
  }

  async getStorageUsage(): Promise<{ totalBytes: number; byCategory: Record<string, number> }> {
    const { data: { session } } = await supabase.auth.getSession();
    const user = session?.user;
    if (!user) return { totalBytes: 0, byCategory: {} };

    const { data, error } = await supabase
      .from('files')
      .select('size_bytes, category')
      .eq('user_id', user.id)
      .is('deleted_at', null);

    if (error) {
      throw new Error(`Failed to get storage usage: ${error.message}`);
    }

    const byCategory: Record<string, number> = {
      video: 0,
      photo: 0,
      document: 0,
      other: 0,
    };

    let totalBytes = 0;
    for (const file of data || []) {
      totalBytes += file.size_bytes;
      byCategory[file.category] = (byCategory[file.category] || 0) + file.size_bytes;
    }

    return { totalBytes, byCategory };
  }

  getCategoryInfo(category: FileCategory) {
    const info: Record<FileCategory, { label: string; color: string }> = {
      video: { label: 'Videos', color: 'text-red-400' },
      photo: { label: 'Photos', color: 'text-blue-400' },
      document: { label: 'Documents', color: 'text-green-400' },
      other: { label: 'Other Files', color: 'text-amber-400' },
    };
    return info[category];
  }
}

export const storageProvider = new StorageProvider();
