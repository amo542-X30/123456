# AM0SP Customer Web App — Supabase setup

## Current status

The customer app is configured for Supabase project `siwuhmlnwzdywhwzxwpl`. On October 6, 2026, all six local migrations were applied to the target project. The read-only storage check confirms:

- `am0sp-vault` is private.
- `storage.objects` RLS is enabled.
- All four storage policies are present for the `authenticated` role and restrict access to the user's own ID folder.

The TUS upload preflight returns HTTP 200 and allows `authorization`, `apikey`, and the required TUS headers. Supabase Storage itself returns its built-in `Access-Control-Allow-Origin: *`; this was not configured or widened by the app changes. The bucket remains private and access is controlled by RLS.

The Edge Function secret `APP_ORIGIN` is set to `https://86f2a9f5-1473-4d37-bb23-e6cffcc1b01d-00-3f037tkrxxya7.pike.replit.dev`. `passkey-auth` is deployed with gateway JWT verification disabled so it can start the unauthenticated WebAuthn login ceremony. Its preflight returns HTTP 200 with this exact allowed origin. An `authentication-options` request returned a challenge and the matching `rpId`.

An authenticated file upload, passkey registration, and completed biometric assertion were not exercised because this workspace has no signed-in customer session or device authenticator. The server-side bucket/policy checks and passkey challenge path were verified.

The archive's `.env` was deliberately excluded. Do not restore it or use its old project credentials.

## Database and storage

Apply the migrations in `supabase/migrations/` in filename order to the new project's SQL Editor, or link the project with the Supabase CLI and run `supabase db push`:

1. `20260930095216_001_am0sp_initial_schema.sql`
2. `20260930100742_002_auto_user_settings.sql`
3. `20261002053408_20261002090000_passkey_authentication_support.sql`
4. `20261003024548_20261003000000_fix_security_audit_critical_and_high.sql`
5. `20261003024713_20261003010000_revoke_public_execute_handle_new_user.sql`
6. `20261005000000_006_ensure_private_vault_bucket.sql`

The schema uses Supabase Auth's built-in `auth.users` for customer accounts and creates these application tables:

- `folders` — per-user folder hierarchy.
- `files` — per-user metadata; file bytes are stored in Storage.
- `devices` — customer sign-in device records.
- `security_events` — customer security-event history.
- `passkeys` — WebAuthn public credential data.
- `passkey_challenges` — short-lived authentication challenges, accessible only to the server-side passkey function.
- `user_settings` — per-user appearance preferences.

The migrations enable row-level security and scope customer access to `auth.uid()`. The `am0sp-vault` Storage bucket is private; object policies restrict each authenticated user to objects under their own user-ID path.

The sixth migration safely ensures the bucket exists and is private without modifying its objects. It has been applied to the configured Supabase project.

To verify the bucket and its owner-scoped object policies without reading customer files, run `supabase/verify_storage_access.sql` in the SQL Editor for the same project configured in this workspace. Expect a `PRIVATE` bucket status, `ENABLED` object RLS, and four `PRESENT` policies scoped to the authenticated user's folder.

There is no public backup bucket. The archive's unused backup migrations were omitted because they created a public bucket and were not used by the customer web app. The archived playback-position migrations created and then removed their table, and no current web feature uses it.

## Connect the customer app

Configure these values in the Replit workspace environment, then restart the workflow:

- `VITE_SUPABASE_URL` — URL shown in the new Supabase project's API settings.
- `VITE_SUPABASE_ANON_KEY` — the project's publishable/anon key. This is public client configuration and is protected by RLS.
- `VITE_APP_URL` — the exact trusted customer-app origin used for password-reset redirects (use `http://localhost:5173` for local Vite development).

Never use a `service_role` or other privileged key for `VITE_SUPABASE_ANON_KEY`. The app shows a setup screen rather than loading mock data if the public project configuration is missing.

In Supabase Auth settings, set the app's site URL and allow the exact password-reset redirect URL, `<VITE_APP_URL>/reset-password`. Add only the real development/production origins that the customer web app uses.

## Deploy Edge Functions

The customer app uses:

- `media-proxy` for authenticated, ownership-checked media access.
- `passkey-auth` for WebAuthn registration and authentication.

Deploy both from `supabase/functions/` after linking the Supabase CLI to the new project. Follow `supabase/config.toml` for JWT verification: `media-proxy` requires a user JWT; `passkey-auth` disables gateway JWT verification so it can start a login ceremony, and performs its own action-specific checks.

Configure `APP_ORIGIN` as an Edge Function secret using the exact trusted app origin. The functions read `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` only on the server. Keep the service-role key in the Supabase Edge Function environment; never copy it into Replit's `VITE_` variables or frontend code. Do not deploy either function until `APP_ORIGIN` and the new project's function environment are set.

## Future Replit Admin Panel

The later Admin Panel can connect to this same project using its project URL and publishable/anon key, then share these migrations and table definitions. It is not included here. Do not expose the service-role key in an Admin Panel browser bundle; any privileged admin operations will need a separately designed server-side authorization and policy model.
